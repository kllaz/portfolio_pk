const recipes = [
  {
    id: 1,
    title: "Салат с авокадо и креветками",
    description: "Легкий и питательный салат, идеально подходящий для обеда",
    tagLabel: "Здоровое питание",
    tagClasses: "bg-green-100 text-green-800",
    time: "25 мин",
    rating: "4.8",
    image:
      "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400&h=300&fit=crop",
    alt: "Салат с авокадо",
  },
  {
    id: 2,
    title: "Домашняя пицца Маргарита",
    description: "Классическая пицца с тонким хрустящим тестом",
    tagLabel: "Итальянская кухня",
    tagClasses: "bg-orange-100 text-orange-800",
    time: "40 мин",
    rating: "4.9",
    image:
      "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=400&h=300&fit=crop",
    alt: "Пицца",
  },
  {
    id: 3,
    title: "Свежий салат с ягодами",
    description: "Витаминный салат для энергичного начала дня",
    tagLabel: "Вегетарианское",
    tagClasses: "bg-purple-100 text-purple-800",
    time: "15 мин",
    rating: "4.7",
    image:
      "https://images.unsplash.com/photo-1540189549336-e6e99c3679fe?w=400&h=300&fit=crop",
    alt: "Салат",
  },
  {
    id: 4,
    title: "Крем-суп из шампиньонов",
    description: "Густой и ароматный суп для уютного вечера",
    tagLabel: "Супы",
    tagClasses: "bg-red-100 text-red-800",
    time: "35 мин",
    rating: "4.6",
    image:
      "https://images.unsplash.com/photo-1567620905732-2d1ec7ab7445?w=400&h=300&fit=crop",
    alt: "Суп",
  },
];

const RecipeCard = ({
  title,
  description,
  tagLabel,
  tagClasses,
  time,
  rating,
  image,
  alt,
}) => (
  <div className="recipe-card rounded-3xl overflow-hidden shadow-xl">
    <div className="relative">
      <img src={image} alt={alt} className="w-full h-64 object-cover" />
      <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm rounded-full px-3 py-1">
        <span className="text-sm font-medium text-gray-700">{time}</span>
      </div>
    </div>
    <div className="p-6">
      <div className="flex items-center mb-3">
        <span
          className={`${tagClasses} text-xs font-medium px-2.5 py-0.5 rounded-full`}
        >
          {tagLabel}
        </span>
      </div>
      <h3 className="font-display text-xl font-semibold text-gray-800 mb-2">
        {title}
      </h3>
      <p className="text-gray-600 text-sm mb-4">{description}</p>
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-1">
          <svg
            className="w-5 h-5 text-yellow-400"
            fill="currentColor"
            viewBox="0 0 20 20"
          >
            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
          </svg>
          <span className="text-sm font-medium text-gray-700">{rating}</span>
        </div>
        <button className="text-green-600 hover:text-green-700 font-medium text-sm">
          Подробнее →
        </button>
      </div>
    </div>
  </div>
);// ВОЗВРАЩАЕМ ТОЛЬКО <li>, БЕЗ <ul>
const RecipeSlider = () => (
  <>
    {recipes.map((recipe) => (
      <li key={recipe.id} className="splide__slide">
        <RecipeCard {...recipe} />
      </li>
    ))}
  </>
);

// Монтируем React и сразу после этого запускаем Splide
const rootElement = document.getElementById("recipe-list-root");

if (rootElement) {
  const root = ReactDOM.createRoot(rootElement);
  root.render(<RecipeSlider />);

  // даём React дорисовать DOM и только потом создаём карусель
  setTimeout(() => {
    if (window.Splide) {
      // на всякий случай уничтожаем старый инстанс, если был
      if (window.recipeSplide) {
        window.recipeSplide.destroy(true);
      }

      window.recipeSplide = new Splide("#recipe-carousel", {
        type: "loop",
        perPage: 3,
        perMove: 1,
        gap: "2rem",
        autoplay: true,
        interval: 4000,
        pauseOnHover: true,
        breakpoints: {
          1024: { perPage: 2 },
          640: { perPage: 1 },
        },
      });

      window.recipeSplide.mount();
    }
  }, 0);
}
