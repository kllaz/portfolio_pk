// Базовый URL для рецептов: берём API_BASE_URL из auth.js и добавляем /api/v1
const RECIPES_API_BASE_URL =
  (typeof API_BASE_URL !== 'undefined' ? API_BASE_URL : 'http://localhost:8080') +
  '/api/v1';

  // Эндпоинт списка покупок (/inventory)
const INVENTORY_ENDPOINT = `${RECIPES_API_BASE_URL}/inventory`;


// Префикс ключа для хранения меню в localStorage
const MENU_STORAGE_PREFIX = "mealplannerWeeklyMenu";

// Сообщение при попытке изменить прошлую неделю
const PAST_WEEK_WARNING = "Нельзя изменять меню прошедших недель";

// Рецепты теперь приходят с бэка, а не из захардкоженного массива
let availableRecipes = [];

// Структура меню: в каждый день — массив id рецептов
let weeklyMenu = {
    monday: [],
    tuesday: [],
    wednesday: [],
    thursday: [],
    friday: [],
    saturday: [],
    sunday: []
};

let currentWeekOffset = 0;
let selectedSlot = null; // { day }

// Начало недели (понедельник) с учётом сдвига по неделям
function getWeekStartDate(offset) {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const startOfWeek = new Date(today);

    // JS: 0 = воскресенье → считаем его как 7-й день
    let day = today.getDay();
    if (day === 0) day = 7;

    // смещаемся к понедельнику + offset недель
    startOfWeek.setDate(today.getDate() - day + 1 + offset * 7);
    startOfWeek.setHours(0, 0, 0, 0);

    return startOfWeek;
}


// === ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ДЛЯ МЕНЮ ===

function createEmptyMenu() {
    return {
        monday: [],
        tuesday: [],
        wednesday: [],
        thursday: [],
        friday: [],
        saturday: [],
        sunday: [],
    };
}

function getMenuStorageKey() {
  const user = getCurrentUserSafe();
  if (!user) return null;

  // Пытаемся сначала взять id, если его нет — используем nickname
  const userKey = user.id || user.nickname;
  if (!userKey) return null;

  return `${MENU_STORAGE_PREFIX}:${userKey}:week:${currentWeekOffset}`;
}


function getWeekStartDate(offset) {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const startOfWeek = new Date(today);

    // JS: 0 = воскресенье → считаем как 7-й день недели
    let day = today.getDay();
    if (day === 0) day = 7;

    // понедельник + offset недель
    startOfWeek.setDate(today.getDate() - day + 1 + offset * 7);
    startOfWeek.setHours(0, 0, 0, 0);

    return startOfWeek;
}


function loadWeeklyMenuFromStorage() {
    const key = getMenuStorageKey();
    if (!key) {
        weeklyMenu = createEmptyMenu();
        return;
    }

    const raw = localStorage.getItem(key);
    if (!raw) {
        weeklyMenu = createEmptyMenu();
        return;
    }

    try {
        const parsed = JSON.parse(raw);
        weeklyMenu = {
            monday: Array.isArray(parsed.monday) ? parsed.monday : [],
            tuesday: Array.isArray(parsed.tuesday) ? parsed.tuesday : [],
            wednesday: Array.isArray(parsed.wednesday) ? parsed.wednesday : [],
            thursday: Array.isArray(parsed.thursday) ? parsed.thursday : [],
            friday: Array.isArray(parsed.friday) ? parsed.friday : [],
            saturday: Array.isArray(parsed.saturday) ? parsed.saturday : [],
            sunday: Array.isArray(parsed.sunday) ? parsed.sunday : [],
        };
    } catch (e) {
        console.warn("Не удалось распарсить сохранённое меню, сбрасываю", e);
        weeklyMenu = createEmptyMenu();
    }
}

function saveWeeklyMenuToStorage() {
    const key = getMenuStorageKey();
    if (!key) return;

    try {
        localStorage.setItem(key, JSON.stringify(weeklyMenu));
    } catch (e) {
        console.warn("Не удалось сохранить меню", e);
    }
}

// === БЕЗОПАСНАЯ РАБОТА С ПОЛЬЗОВАТЕЛЕМ / АВТОРИЗАЦИЕЙ ===

// безопасно достаём текущего юзера из auth.js
function getCurrentUserSafe() {
    if (typeof window !== "undefined" && typeof window.getCurrentUser === "function") {
        try {
            return window.getCurrentUser();
        } catch {
            return null;
        }
    }
    return null;
}

// безопасно достаём заголовки авторизации
function getAuthHeadersSafe() {
    if (typeof window !== "undefined" && typeof window.getAuthHeaders === "function") {
        try {
            return window.getAuthHeaders();
        } catch {
            // noop
        }
    }

    const user = getCurrentUserSafe();
    if (user && user.token) {
        return { Authorization: `Bearer ${user.token}` };
    }
    return {};
}

// Собираем продукты из одного рецепта (как в shopping.js, но без дней недели)
function collectNeededProductsFromRecipe(recipe) {
    if (!recipe || !Array.isArray(recipe.ingredients)) return [];

    /** key = lowerName, value = { name, quantity } */
    const result = {};

    recipe.ingredients.forEach((ing) => {
        let name = null;

        if (typeof ing === 'string') {
            name = ing.trim();
        } else if (ing && typeof ing === 'object') {
            name =
                ing.product_name ||
                ing.ProductName ||
                ing.name ||
                ing.Name ||
                ing.title ||
                ing.Title ||
                null;

            if (typeof name === 'string') {
                name = name.trim();
            }
        }

        if (!name) return;

        // количество (если есть в БД)
        let qty = 1;
        if (ing && typeof ing === 'object') {
            const rawQ = ing.quantity ?? ing.Quantity;
            if (rawQ != null && rawQ !== '') {
                const n = parseInt(rawQ, 10);
                if (!Number.isNaN(n) && n > 0) {
                    qty = n;
                }
            }
        }

        const key = name.toLowerCase();
        if (!result[key]) {
            result[key] = { name, quantity: qty };
        } else {
            result[key].quantity += qty;
        }
    });

    return Object.values(result);
}

async function createInventoryItemFromMenu(productName, quantity) {
    const user = getCurrentUserSafe();
    if (!user || !user.token) {
        console.warn("Нет авторизованного пользователя — inventory недоступен");
        return null;
    }

    try {
        const res = await fetch(INVENTORY_ENDPOINT, {
            method: 'POST',
            headers: {
                ...getAuthHeadersSafe(),
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                product_name: productName,
                quantity: quantity,
            }),
        });

        if (res.status === 401) {
            handleSessionExpired();
            return;
        }

        if (!res.ok) {
            let payload = null;
            try {
                payload = await res.json();
            } catch {
                // noop
            }
            console.error('Не удалось добавить продукт из меню в shopping:', res.status, payload);
            return null;
        }

        // Тело ответа нам здесь не особо нужно
        return true;
    } catch (err) {
        console.error('Ошибка при добавлении продукта из меню в shopping:', err);
        return null;
    }
}


async function addRecipeIngredientsToShopping(recipe) {
    const products = collectNeededProductsFromRecipe(recipe);
    if (!products.length) return;

    for (const p of products) {
        const name = p.name && p.name.trim();
        if (!name) continue;

        const qty = p.quantity || 1;
        await createInventoryItemFromMenu(name, qty);
    }

    // всё добавили тихо, без лишних уведомлений — список подтянется на shopping.html
}


// === ПРОВЕРКА: МОЖНО ЛИ РЕДАКТИРОВАТЬ ТЕКУЩУЮ НЕДЕЛЮ ===

// Прошедшие недели: currentWeekOffset < 0
// Текущая и будущие недели: currentWeekOffset >= 0
function isCurrentWeekEditable() {
    return currentWeekOffset >= 0;
}

// Загрузка рецептов с бэка
async function loadAvailableRecipes() {
    const user = getCurrentUserSafe();

    if (!user || !user.token) {
        console.warn("Нет авторизованного пользователя — рецепты недоступны.");
        showNotification("Войдите, чтобы увидеть свои рецепты");
        return;
    }

    try {
        // ВАЖНО: берём те же рецепты, что и shopping.js
        const response = await fetch(`${RECIPES_API_BASE_URL}/recipes`, {
            method: "GET",
            headers: {
                ...getAuthHeadersSafe(),
            },
        });

        // токен истёк / невалиден
        if (response.status === 401) {
            console.warn("Токен недействителен или истёк");

            if (typeof window !== "undefined" && typeof window.clearUserSession === "function") {
                window.clearUserSession();
            } else {
                localStorage.removeItem("mealplannerUser");
            }

            window.location.href = "login.html";
            return;
        }

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }

        const data = await response.json().catch(() => null);
        console.log("Recipes payload from API (menu):", data);

        let recipesArray = [];

        if (Array.isArray(data)) {
            recipesArray = data;
        } else if (data && Array.isArray(data.recipes)) {
            recipesArray = data.recipes;
        } else if (data && Array.isArray(data.data)) {
            recipesArray = data.data;
        } else if (data === null) {
            console.warn("Сервер вернул null, считаем, что рецептов пока нет");
            recipesArray = [];
        } else {
            console.error("Неожиданный формат данных рецептов:", data);
            showNotification("Ошибка формата данных рецептов с сервера");
            return;
        }

        // здесь уже должны быть ingredients
        availableRecipes = recipesArray.map((r) => ({
            id: r.id || r.ID,
            title: r.title || r.name || "Без названия",
            description: r.description || "",
            ingredients: Array.isArray(r.ingredients) ? r.ingredients : [],
            steps: Array.isArray(r.steps) ? r.steps : [],
        }));

        cleanupWeeklyMenuFromMissingRecipes();

        if (!availableRecipes.length) {
            showNotification("У вас пока нет рецептов");
        }

        updateCalendar();
    } catch (err) {
        console.error("Не удалось загрузить рецепты:", err);
        showNotification("Ошибка при загрузке рецептов");
    }
}



document.addEventListener("DOMContentLoaded", async function () {
    // сначала подтянем сохранённое меню для текущей недели (если есть)
    loadWeeklyMenuFromStorage();

    initializeCalendar();
    initializeNavigation();
    updateWeekDisplay();
    updateStats();

    await loadAvailableRecipes();
    renderRecipeSelection();
});

// Инициализация календаря
// Инициализация календаря
function initializeCalendar() {
    const grid = document.getElementById("calendar-grid");
    const days = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"];
    const dayNames = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"];

    const editable = isCurrentWeekEditable();

    // начало просматриваемой недели и "сегодня"
    const viewStart = getWeekStartDate(currentWeekOffset);
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    days.forEach((day, dayIndex) => {
        const dayCell = document.createElement("div");
        dayCell.className = "calendar-day border border-gray-200 h-fit rounded-lg p-3 flex flex-col";

        const dayHeader = document.createElement("div");
        dayHeader.className = "font-semibold text-gray-800 mb-2 text-sm";
        dayHeader.textContent = dayNames[dayIndex];
        dayCell.appendChild(dayHeader);

        const recipesContainer = document.createElement("div");
        recipesContainer.className = "space-y-2 mb-2";
        recipesContainer.dataset.day = day;

        const recipesForDay = weeklyMenu[day] || [];

        if (recipesForDay.length === 0) {
            const emptyText = document.createElement("div");
            emptyText.className = "text-xs text-gray-400";
            emptyText.textContent = editable
                ? 'Нет рецептов. Нажмите "Добавить".'
                : "Нет рецептов.";
            recipesContainer.appendChild(emptyText);
        } else {
            recipesForDay.forEach((recipeId, index) => {
                const recipe = availableRecipes.find(r => r.id === recipeId);
                if (!recipe) return;

                const recipeSlot = document.createElement("div");
                recipeSlot.className = "meal-slot break-all filled rounded-lg p-2";

                if (editable) {
                    recipeSlot.classList.add("cursor-default");
                    recipeSlot.innerHTML = `
                        <div class="text-xs font-medium">${recipe.title}</div>
                        <button class="mt-1 text-[10px] underline decoration-dotted opacity-80 hover:opacity-100">
                            Удалить
                        </button>
                    `;

                    const removeButton = recipeSlot.querySelector("button");
                    removeButton.addEventListener("click", (e) => {
                        e.stopPropagation();
                        weeklyMenu[day].splice(index, 1);
                        updateCalendar();
                    });
                } else {
                    recipeSlot.innerHTML = `
                        <div class="text-xs font-medium">${recipe.title}</div>
                    `;
                }

                recipesContainer.appendChild(recipeSlot);
            });
        }

        dayCell.appendChild(recipesContainer);

        const addButton = document.createElement("button");
        addButton.className = "mt-auto w-full border-2 border-dashed border-gray-300 text-[#292929] opacity-70 text-xs py-1.5 rounded-lg transition-all duration-200";

        if (editable) {
            addButton.classList.add("hover:opacity-100", "hover:border-[#126df7]", "hover:text-[#126df7]");
            addButton.textContent = "+ Добавить рецепт";
            addButton.addEventListener("click", () => openRecipeSelection(day));
        } else {
            addButton.disabled = true;
            addButton.classList.add("opacity-40", "cursor-not-allowed");
            addButton.textContent = "Прошлая неделя (только просмотр)";
        }

        dayCell.appendChild(addButton);

        // ===== Подсветка сегодняшнего дня =====
        const dayDate = new Date(viewStart);
        dayDate.setDate(viewStart.getDate() + dayIndex);
        dayDate.setHours(0, 0, 0, 0);

        const isToday =
            dayDate.getFullYear() === today.getFullYear() &&
            dayDate.getMonth() === today.getMonth() &&
            dayDate.getDate() === today.getDate();

        if (isToday) {
            // фон поярче + обводка
            dayCell.classList.add(
                "bg-white",
                "ring-2",
                "ring-[#126df7]",
                "ring-offset-2",
                "ring-offset-white"
            );
        }

        grid.appendChild(dayCell);
    });
}


// Навигация по неделям
function initializeNavigation() {
    document.getElementById("prev-week").addEventListener("click", () => {
        currentWeekOffset--;
        loadWeeklyMenuFromStorage(); // меню для этой недели
        updateWeekDisplay();
        updateCalendar();
    });

    document.getElementById("next-week").addEventListener("click", () => {
        currentWeekOffset++;
        loadWeeklyMenuFromStorage(); // меню для новой недели
        updateWeekDisplay();
        updateCalendar();
    });
}


// Обновление текста недели
function updateWeekDisplay() {
    const startOfWeek = getWeekStartDate(currentWeekOffset);
    const endOfWeek = new Date(startOfWeek);
    endOfWeek.setDate(startOfWeek.getDate() + 6);

    const options = { month: "long", year: "numeric" };
    const weekMonthYear = startOfWeek.toLocaleDateString("ru-RU", options);

    const startDay = startOfWeek.getDate();
    const endDay = endOfWeek.getDate();
    const weekRangeText = `${startDay} - ${endDay} ${weekMonthYear}`;

    document.getElementById("current-week").textContent = weekMonthYear;
    document.getElementById("week-range").textContent = weekRangeText;
}


// Перерисовать календарь
function updateCalendar() {
    const grid = document.getElementById("calendar-grid");
    grid.innerHTML = "";
    initializeCalendar();
    updateStats();
    saveWeeklyMenuToStorage();
}

// Статистика
function updateStats() {
    let plannedMeals = 0;
    let uniqueRecipes = new Set();

    Object.values(weeklyMenu).forEach(dayMenu => {
        dayMenu.forEach(recipeId => {
            if (recipeId) {
                plannedMeals++;
                uniqueRecipes.add(recipeId);
            }
        });
    });

    document.getElementById("planned-meals").textContent = plannedMeals;
    document.getElementById("unique-recipes").textContent = uniqueRecipes.size;
}

function cleanupWeeklyMenuFromMissingRecipes() {
    if (!availableRecipes || !availableRecipes.length) return;

    const validIds = new Set(availableRecipes.map(r => r.id));
    const days = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"];

    let changed = false;

    days.forEach((day) => {
        const dayMenu = Array.isArray(weeklyMenu[day]) ? weeklyMenu[day] : [];
        const filtered = dayMenu.filter((id) => validIds.has(id));

        if (filtered.length !== dayMenu.length) {
            weeklyMenu[day] = filtered;
            changed = true;
        }
    });

    if (changed) {
        saveWeeklyMenuToStorage();
        updateStats();
    }
}


// Открыть модалку выбора рецепта
function openRecipeSelection(day) {
    // Блокируем попытку открыть модалку для прошлых недель
    if (!isCurrentWeekEditable()) {
        showNotification(PAST_WEEK_WARNING);
        return;
    }

    selectedSlot = { day };
    const modal = document.getElementById("recipe-modal");
    const content = document.getElementById("modal-content");

    modal.classList.remove("hidden");

    setTimeout(() => {
        content.style.transform = "scale(1)";
        content.style.opacity = "1";
    }, 10);
}

// Закрыть модалку
function hideRecipeModal() {
    const modal = document.getElementById("recipe-modal");
    const content = document.getElementById("modal-content");

    content.style.transform = "scale(0.95)";
    content.style.opacity = "0";

    setTimeout(() => {
        modal.classList.add("hidden");
    }, 300);
}

// Рендер сетки выбора рецептов
function renderRecipeSelection() {
    const grid = document.getElementById("recipe-selection-grid");
    grid.innerHTML = "";

    if (!availableRecipes.length) {
        grid.innerHTML = `
            <div class="col-span-full text-sm text-gray-500">
                Нет доступных рецептов. Создайте их в разделе "Рецепты".
            </div>
        `;
        return;
    }

    availableRecipes.forEach(recipe => {
        const card = document.createElement("div");
        card.className = "recipe-card rounded-xl p-4 cursor-pointer border border-gray-100 hover:border[#292929] transition";

        card.innerHTML = `
            <h4 class="font-semibold text-gray-800 mb-1 text-sm">${recipe.title}</h4>
            ${recipe.description ? `<p class="text-xs text-gray-500 mb-2 line-clamp-2">${recipe.description}</p>` : ""}
        `;

        card.addEventListener("click", () => selectRecipe(recipe));
        grid.appendChild(card);
    });

    // Поиск по названию
    const searchInput = document.getElementById("recipe-search");
    searchInput.addEventListener("input", function() {
        const searchTerm = this.value.toLowerCase();
        const cards = grid.querySelectorAll(".recipe-card");

        cards.forEach(card => {
            const title = card.querySelector("h4").textContent.toLowerCase();
            if (title.includes(searchTerm)) {
                card.style.display = "block";
            } else {
                card.style.display = "none";
            }
        });
    });
}

// Выбор рецепта
async function selectRecipe(recipe) {
    if (!isCurrentWeekEditable()) {
        showNotification(PAST_WEEK_WARNING);
        return;
    }

    if (selectedSlot && selectedSlot.day) {
        if (!Array.isArray(weeklyMenu[selectedSlot.day])) {
            weeklyMenu[selectedSlot.day] = [];
        }

        // 1) Добавляем рецепт в меню
        weeklyMenu[selectedSlot.day].push(recipe.id);
        updateCalendar();
        hideRecipeModal();

        // 2) Отправляем ингредиенты этого рецепта в /api/v1/inventory
        //    (по сути то же, что "Сгенерировать из меню", но точечно)
        addRecipeIngredientsToShopping(recipe); // fire-and-forget

        showNotification(`Рецепт "${recipe.title}" добавлен!`);
    }
}



// Генерация недельного меню (случайные рецепты на день)
function generateWeeklyMenu() {
    if (!isCurrentWeekEditable()) {
        showNotification(PAST_WEEK_WARNING);
        return;
    }

    if (!availableRecipes.length) {
        showNotification("Нет рецептов для генерации меню");
        return;
    }

    const days = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"];
    const recipesPerDay = 3;

    days.forEach(day => {
        weeklyMenu[day] = [];
        for (let i = 0; i < recipesPerDay; i++) {
            const randomRecipe = availableRecipes[Math.floor(Math.random() * availableRecipes.length)];
            weeklyMenu[day].push(randomRecipe.id);
        }
    });

    updateCalendar();
    showNotification("Меню на неделю сгенерировано!");
}

// Очистить меню недели
function clearWeekMenu() {
    if (!isCurrentWeekEditable()) {
        showNotification(PAST_WEEK_WARNING);
        return;
    }

    const days = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"];

    days.forEach(day => {
        weeklyMenu[day] = [];
    });

    updateCalendar();
    showNotification("Меню очищено!");
}

// Экспорт меню (можно и для прошлых недель)
function exportMenu() {
    const days = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"];
    const dayNames = ["Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"];

    let exportText = "Моё меню на неделю\n\n";

    days.forEach((day, index) => {
        exportText += `${dayNames[index]}:\n`;
        const recipesForDay = weeklyMenu[day] || [];
        if (recipesForDay.length === 0) {
            exportText += "  Нет рецептов\n\n";
            return;
        }

        recipesForDay.forEach(recipeId => {
            const recipe = availableRecipes.find(r => r.id === recipeId);
            exportText += `  - ${recipe ? recipe.title : "Неизвестный рецепт"}\n`;
        });
        exportText += "\n";
    });

    const blob = new Blob([exportText], { type: "text/plain" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "меню-на-неделю.txt";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);

    showNotification("Меню экспортировано!");
}

// Небольшие нотификации справа сверху
function showNotification(message) {
    const notification = document.createElement("div");
    notification.className = "fixed top-20 right-4 bg-[#f6f7f8] text-[#292929] px-6 py-3 rounded-lg shadow-lg z-50 transform translate-x-full transition-transform duration-300";
    notification.textContent = message;

    document.body.appendChild(notification);

    setTimeout(() => {
        notification.style.transform = "translateX(0)";
    }, 100);

    setTimeout(() => {
        notification.style.transform = "translateX(100%)";
        setTimeout(() => {
            if (notification.parentNode) {
                document.body.removeChild(notification);
            }
        }, 300);
    }, 3000);
}

// Закрытие модалки по клику вне окна
document.getElementById("recipe-modal").addEventListener("click", function(e) {
    if (e.target === this) {
        hideRecipeModal();
    }
});

// Ховер-анимации для карточек рецептов в календаре (если anime.js подключен)
document.addEventListener("mouseenter", function(e) {
    if (e.target && e.target.classList && e.target.classList.contains("meal-slot")) {
        if (typeof anime !== "undefined") {
            anime({
                targets: e.target,
                scale: 1.02,
                duration: 200,
                easing: "easeOutCubic"
            });
        }
    }
}, true);

document.addEventListener("mouseleave", function(e) {
    if (e.target && e.target.classList && e.target.classList.contains("meal-slot")) {
        if (typeof anime !== "undefined") {
            anime({
                targets: e.target,
                scale: 1,
                duration: 200,
                easing: "easeOutCubic"
            });
        }
    }
}, true);
