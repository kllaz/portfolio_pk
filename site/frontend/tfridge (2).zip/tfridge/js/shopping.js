// js/shopping.js

// ==== API ====


// Берём базовый URL, который объявлен в auth.js (API_BASE_URL),
// и добавляем префикс /api/v1 для эндпоинтов продуктов/инвентаря
const API_V1_BASE =
  (typeof API_BASE_URL !== 'undefined' ? API_BASE_URL : 'http://localhost:8080') +
  '/api/v1';
const INVENTORY_ENDPOINT = `${API_V1_BASE}/inventory`;
const PRODUCTS_ENDPOINT  = `${API_V1_BASE}/products`;

const PRODUCT_SEARCH_ENDPOINT = `${PRODUCTS_ENDPOINT}/search`;

// === Интеграция с меню недели ===

// тот же префикс, что и в menu.js
const MENU_STORAGE_PREFIX = 'mealplannerWeeklyMenu';

// рецепты лежат на том же /api/v1
const RECIPES_API_BASE_URL = API_V1_BASE;



// ==== Состояние ====

let shoppingItems = [];      // то, что показываем на странице
let allProducts   = [];      // все продукты из БД для подсказок
function normalizeUnit(unit) {
  if (!unit) return '';
  const u = String(unit).toLowerCase();

  const map = {
    kg: 'кг',
    kilogram: 'кг',
    kilograms: 'кг',
    г: 'г',
    g: 'г',
    gram: 'г',
    grams: 'г',
    l: 'л',
    lt: 'л',
    liter: 'л',
    litre: 'л',
    liters: 'л',
    ml: 'мл',
    milliliter: 'мл',
    millilitre: 'мл',
    pcs: 'шт',
    piece: 'шт',
    pieces: 'шт',
    unit: 'шт',
  };

  return map[u] || unit;
}

function getUnitForProductName(name) {
  if (!name || !allProducts.length) return null;
  const lower = String(name).toLowerCase();
  const found = allProducts.find(
    (p) => p.name && p.name.toLowerCase() === lower,
  );
  return found && found.unit ? found.unit : null;
}

function updateQuantityUnitLabel() {
  const labelEl = document.getElementById('item-unit-label');
  if (!labelEl) return;

  const nameInput = document.getElementById('item-name');
  const name = nameInput ? nameInput.value.trim() : '';
  if (!name) {
    labelEl.textContent = '';
    return;
  }

  let unit = null;

  if (selectedProduct && selectedProduct.name) {
    const selLower = selectedProduct.name.toLowerCase();
    if (selLower === name.toLowerCase()) {
      unit = selectedProduct.unit || null;
    }
  }

  if (!unit) {
    unit = getUnitForProductName(name);
  }

  labelEl.textContent = unit ? normalizeUnit(unit) : '';
}


let productsLoaded        = false;
let productsLoadingPromise = null;

let selectedProduct   = null;
let currentSuggestions = [];
let suggestionsContainer = null;
let productSearchDebounceId = null;

// ==== вспомогалки auth.js ====

function getCurrentUserSafe() {
  try {
    if (window.getCurrentUser) return window.getCurrentUser();
  } catch (e) {
    console.warn('getCurrentUserSafe error', e);
  }
  return null;
}

function getAuthHeadersSafe() {
  try {
    if (window.getAuthHeaders) return window.getAuthHeaders();
  } catch (e) {
    console.warn('getAuthHeadersSafe error', e);
  }
  return {};
}

// ==== init ====

document.addEventListener('DOMContentLoaded', () => {
  initShoppingPage();
});

async function initShoppingPage() {
  initializeAddItemForm();
  initProductSearchUI();
  updateStats();
  renderShoppingList();

  // заранее подгружаем продукты, чтобы знать единицы измерения
  try {
    await ensureProductsLoaded();
  } catch (e) {
    console.warn('Не удалось загрузить список продуктов', e);
  }

  const user = getCurrentUserSafe();
  if (!user || !user.token) {
    showNotification('Войдите, чтобы сохранять список продуктов');
    return;
  }

  await fetchUserInventory();
}

// ==== API: инвентарь ====
function mapApiIngredientToItem(ing) {
  const name =
    ing.product_name ||
    ing.ProductName ||
    ing.name ||
    ing.Name ||
    'Без названия';

  const unit =
    ing.measurement ||
    ing.Measurement ||
    ing.unit ||
    ing.Unit ||
    null;

  return {
    id:        ing.id || ing.ID || null,
    name,
    quantity:  ing.quantity ?? ing.Quantity ?? 1,
    unit,                // <-- добавили
    completed: false,
  };
}

function formatUnit(unit) {
  if (!unit) return '';
  const u = String(unit).toLowerCase();

  const map = {
    kg: 'кг',
    kilogram: 'кг',
    g: 'г',
    gram: 'г',
    l: 'л',
    liter: 'л',
    ml: 'мл',
    milliliter: 'мл',
    pcs: 'шт',
    piece: 'шт',
    unit: 'шт',
  };

  return map[u] || unit; // если пришло что-то своё – показываем как есть
}

function enrichItemsWithUnits(items) {
  if (!Array.isArray(items) || !allProducts.length) return;

  const dict = new Map(
    allProducts
      .filter((p) => p && p.name)
      .map((p) => [p.name.toLowerCase(), p.unit || null]),
  );

  items.forEach((item) => {
    if (!item || item.unit || !item.name) return;
    const u = dict.get(item.name.toLowerCase());
    if (u) item.unit = u;
  });
}



async function fetchUserInventory() {
  const container = document.getElementById('shopping-list-container');
  if (container) {
    container.innerHTML = `<p class="text-gray-500 text-sm">Загружаем ваши продукты...</p>`;
  }

  try {
    const res = await fetch(INVENTORY_ENDPOINT, {
      method: 'GET',
      headers: {
        ...getAuthHeadersSafe(),
        'Content-Type': 'application/json',
      },
    });

if (res.status === 401) {
  handleSessionExpired();
  return;
}


    if (!res.ok) {
      console.error('Failed to load inventory:', res.status);
      showNotification('Не удалось загрузить список продуктов');
      return;
    }

    const data = await res.json();
    if (Array.isArray(data)) {
      shoppingItems = data.map(mapApiIngredientToItem);
    } else {
      shoppingItems = [];
    }

    renderShoppingList();
    updateStats();
  } catch (err) {
    console.error('Error loading inventory:', err);
    showNotification('Сервер недоступен');
  }

      if (Array.isArray(data)) {
      shoppingItems = data.map(mapApiIngredientToItem);
    } else {
      shoppingItems = [];
    }

    await ensureProductsLoaded();
    enrichItemsWithUnits(shoppingItems);

    renderShoppingList();
    updateStats();

}

async function createInventoryItem(product, quantity) {
  const user = getCurrentUserSafe();
  if (!user || !user.token) {
    showNotification('Войдите, чтобы добавлять продукты');
    return null;
  }

  try {
    const res = await fetch(INVENTORY_ENDPOINT, {
      method: 'POST',
      headers: {
        ...getAuthHeadersSafe(),
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
  product_name: product.name, // строка из справочника продуктов
  quantity: quantity,
}),

    });
if (res.status === 401) {
  handleSessionExpired();
  return null;
}


    if (!res.ok) {
      const payload = await res.json().catch(() => ({}));
      console.error('Failed to create inventory item:', res.status, payload);
      showNotification(payload.error || 'Не удалось добавить продукт');
      return null;
    }

    const payload = await res.json();
    const ing = payload.ingredient || payload;
    const item = mapApiIngredientToItem(ing);

    await ensureProductsLoaded();
    enrichItemsWithUnits([item]);

    return item;

  } catch (err) {
    console.error('Error creating inventory item:', err);
    showNotification('Сервер недоступен');
    return null;
  }
}

async function deleteInventoryItem(id) {
  if (!id) return false;

  try {
    const res = await fetch(`${INVENTORY_ENDPOINT}/${encodeURIComponent(id)}`, {
      method: 'DELETE',
      headers: {
        ...getAuthHeadersSafe(),
      },
    });

if (res.status === 401) {
  handleSessionExpired();
  return false;
}


    if (!res.ok) {
      console.error('Failed to delete inventory item:', res.status);
      showNotification('Не удалось удалить продукт');
      return false;
    }

    return true;
  } catch (err) {
    console.error('Error deleting inventory item:', err);
    showNotification('Сервер недоступен');
    return false;
  }
}

// ==== API: продукты (для подсказок) ====

async function ensureProductsLoaded() {
  if (productsLoaded) return;
  if (productsLoadingPromise) return productsLoadingPromise;

  productsLoadingPromise = (async () => {
    try {
      const res = await fetch(PRODUCTS_ENDPOINT, {
        method: 'GET',
        headers: {
          ...getAuthHeadersSafe(),
          'Content-Type': 'application/json',
        },
      });

      if (!res.ok) {
        console.error('Failed to load products:', res.status);
        return;
      }

      const data = await res.json();
      if (!Array.isArray(data)) return;

 allProducts = data
  .map((p) => ({
    // /products возвращает ProductResponse: { name, measurement, ... }
    name: p.name || p.Name,
    unit:
      p.measurement ||
      p.Measurement ||
      p.unit ||
      p.Unit ||
      null,
  }))
  .filter((p) => p.name);


      productsLoaded = true;
    } catch (err) {
      console.error('Error loading products list:', err);
    }
  })();

  return productsLoadingPromise;
}

// Поиск продуктов по префиксу через trie (/api/v1/products/search)
// Поиск продуктов по префиксу через trie (/api/v1/products/search)
async function searchProductsByPrefix(prefix, limit = 10) {
  const q = (prefix || '').trim().toLowerCase();
  if (!q) return [];

  await ensureProductsLoaded();

  const params = new URLSearchParams();
  params.set('prefix', q);
  params.set('limit', String(limit));

  try {
    const res = await fetch(`${PRODUCT_SEARCH_ENDPOINT}?${params.toString()}`, {
      method: 'GET',
      headers: {
        ...getAuthHeadersSafe(),
        'Content-Type': 'application/json',
      },
    });

    if (res.status === 401) {handleSessionExpired();
      return [];
    }

    if (!res.ok) {
      console.error('Failed to search products by prefix:', res.status);
      return [];
    }

    const data = await res.json();

    let names = [];
    if (Array.isArray(data)) {
      names = data;
    } else if (Array.isArray(data.results)) {
      names = data.results;
    }

    const dict = new Map(
      allProducts.map((p) => [p.name.toLowerCase(), p.unit || null]),
    );

    return names
      .filter((name) => typeof name === 'string' && name.trim())
      .map((name) => {
        const trimmed = name.trim();
        const key     = trimmed.toLowerCase();
        return {
          name: trimmed,
          unit: dict.get(key) || null,
        };
      });
  } catch (err) {
    console.error('Error searching products by prefix:', err);
    return [];
  }
}

// === Работа с меню недели (только текущая неделя) ===

function createEmptyMenuForShopping() {
  return {
    monday: [],
    tuesday: [],
    wednesday: [],
    thursday: [],
    friday: [],
    saturday: [],
    sunday: [],
  };
}

function loadCurrentWeekMenuFromStorage() {
  
  const user = getCurrentUserSafe();
  if (!user) return createEmptyMenuForShopping();

  const userKey = user.id || user.nickname;
  if (!userKey) return createEmptyMenuForShopping();

  // currentWeekOffset = 0 — текущая неделя
  const key = `${MENU_STORAGE_PREFIX}:${userKey}:week:0`;
  const raw = localStorage.getItem(key);
  if (!raw) return createEmptyMenuForShopping();

  try {
    const parsed = JSON.parse(raw);
    return {
      monday: Array.isArray(parsed.monday) ? parsed.monday : [],
      tuesday: Array.isArray(parsed.tuesday) ? parsed.tuesday : [],
      wednesday: Array.isArray(parsed.wednesday) ? parsed.wednesday : [],
      thursday: Array.isArray(parsed.thursday) ? parsed.thursday : [],
      friday: Array.isArray(parsed.friday) ? parsed.friday : [],
      saturday: Array.isArray(parsed.saturday) ? parsed.saturday : [],
      sunday: Array.isArray(parsed.sunday) ? parsed.sunday : [],
    };
  } catch (e) {
    console.warn('Не удалось распарсить меню недели из localStorage', e);
    return createEmptyMenuForShopping();
  }
}

// Подтягиваем рецепты пользователя (почти как в menu.js)
async function fetchUserRecipesForShopping() {
  const user = getCurrentUserSafe();
  if (!user || !user.token) {
    showNotification('Войдите, чтобы использовать меню');
    return [];
  }

  try {
    const res = await fetch(`${RECIPES_API_BASE_URL}/recipes/user/my`, {
      method: 'GET',
      headers: {
        ...getAuthHeadersSafe(),
      },
    });

    if (res.status === 401) {
      handleSessionExpired();
      return [];
    }

    if (!res.ok) {
      console.error('Failed to load recipes for shopping:', res.status);
      showNotification('Не удалось загрузить рецепты');
      return [];
    }

    const data = await res.json().catch(() => null);
    let recipesArray = [];

    if (Array.isArray(data)) {
      recipesArray = data;
    } else if (data && Array.isArray(data.recipes)) {
      recipesArray = data.recipes;
    } else if (data && Array.isArray(data.data)) {
      recipesArray = data.data;
    } else if (data === null) {
      console.warn('Сервер вернул null для рецептов');
      recipesArray = [];
    } else {
      console.error('Неожиданный формат рецептов в shopping.js:', data);
      showNotification('Ошибка формата данных рецептов');
      return [];
    }

    return recipesArray.map((r) => ({
      id: r.id || r.ID,
      title: r.title || r.name || 'Без названия',
      ingredients: Array.isArray(r.ingredients) ? r.ingredients : [],
    }));
  } catch (err) {
    console.error('Не удалось загрузить рецепты для shopping:', err);
    showNotification('Ошибка при загрузке рецептов');
    return [];
  }
}

// Собираем нужные продукты из меню + рецептов
function collectNeededProductsFromMenu(weeklyMenu, recipes) {
  const days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
  const recipesById = new Map();

  recipes.forEach((r) => {
    if (!r || r.id == null) return;
    recipesById.set(String(r.id), r);
  });

  /** структура: key = lowerName, value = { name, quantity } */
  const result = {};

  days.forEach((day) => {
    const ids = Array.isArray(weeklyMenu[day]) ? weeklyMenu[day] : [];
    ids.forEach((rid) => {
      if (!rid && rid !== 0) return;

      const recipe = recipesById.get(String(rid));
      if (!recipe || !Array.isArray(recipe.ingredients)) return;

      recipe.ingredients.forEach((ing) => {
        let name = null;

        if (typeof ing === 'string') {
          name = ing.trim();
        } else if (ing && typeof ing === 'object') {
          name =
            ing.product_name ||
            ing.ProductName ||
            ing.name ||
            ing.Name ||
            ing.title ||
            ing.Title ||
            null;
          if (typeof name === 'string') {
            name = name.trim();
          }
        }

        if (!name) return;

        // пытаемся вытащить количество, если оно есть
        let qty = 1;
        if (ing && typeof ing === 'object') {
          const rawQ = ing.quantity ?? ing.Quantity;
          if (rawQ != null && rawQ !== '') {
            const n = parseInt(rawQ, 10);
            if (!Number.isNaN(n) && n > 0) {
              qty = n;
            }
          }
        }

        const key = name.toLowerCase();
        if (!result[key]) {
          result[key] = { name, quantity: qty };
        } else {
          result[key].quantity += qty;
        }
      });
    });
  });

  return Object.values(result);
}


// ==== рендер списка ====

function renderShoppingList() {
  const container = document.getElementById('shopping-list-container');
  if (!container) return;

if (!shoppingItems.length) {
  container.innerHTML = `
      <p class="text-gray-500 text-sm">
        Список пока пуст. Добавьте первый продукт с помощью кнопки «Добавить продукт» справа.
      </p>
    `;
  return;
}


  container.innerHTML = `
    <div class="space-y-3">
      ${shoppingItems.map(createItemHTML).join('')}
    </div>
  `;
}

function createItemHTML(item) {
  const quantityText = item.quantity != null ? String(item.quantity) : '';
  const unit         = getUnitForProductName(item.name);
  const unitText     = unit ? ` ${normalizeUnit(unit)}` : '';

  return `
    <div class="shopping-item flex items-center space-x-3 p-2 rounded-lg ${
      item.completed ? 'completed' : ''
    }" data-item-id="${item.id}">
      <div class="flex-1">
        <div class="font-medium text-gray-800">${item.name}</div>
        <div class="text-sm text-gray-600">
          ${quantityText ? `${quantityText}${unitText}` : ''}
        </div>
      </div>
      <button class="text-red-400 hover:text-red-600 transition-colors duration-200"
              onclick="removeItem('${item.id}')">
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
        </svg>
      </button>
    </div>
  `;
}


function toggleItem(itemId) {
  const item = shoppingItems.find((i) => String(i.id) === String(itemId));
  if (!item) return;

  item.completed = !item.completed;

  const el = document.querySelector(`[data-item-id="${CSS.escape(String(itemId))}"]`);
  if (el && window.anime) {
    anime({
      targets: el,
      scale: [1, 1.05, 1],
      duration: 300,
      easing: 'easeOutCubic',
    });
  }

  renderShoppingList();
  updateStats();
}

async function removeItem(itemId) {
  const item = shoppingItems.find((i) => String(i.id) === String(itemId));
  if (!item) return;

  const ok = await deleteInventoryItem(item.id);
  if (!ok) return;

  shoppingItems = shoppingItems.filter((i) => String(i.id) !== String(itemId));
  renderShoppingList();
  updateStats();
  showNotification('Продукт удалён из списка');
}

// ==== статистика ====

function updateStats() {
  const totalItems     = shoppingItems.length;
  const completedItems = shoppingItems.filter((i) => i.completed).length;
  const remainingItems = totalItems - completedItems;
  const progress       = totalItems ? Math.round((completedItems / totalItems) * 100) : 0;

  const totalEl     = document.getElementById('total-items');
  const completedEl = document.getElementById('completed-items');
  const remainingEl = document.getElementById('remaining-items');

  if (totalEl)     totalEl.textContent = String(totalItems);
  if (completedEl) completedEl.textContent = String(completedItems);
  if (remainingEl) remainingEl.textContent = String(remainingItems);

  const progressText = document.getElementById('progress-text');
  if (progressText) progressText.textContent = `${progress}% выполнено`;

  const progressBar = document.getElementById('progress-bar');
  if (progressBar && window.anime) {
    anime({
      targets: progressBar,
      width: `${progress}%`,
      duration: 800,
      easing: 'easeOutCubic',
    });
  }
}

// ==== модалка добавления ====
function showAddItemModal() {
  const modal   = document.getElementById('add-item-modal');
  const content = document.getElementById('modal-content');
  if (!modal || !content) return;

  modal.classList.remove('hidden');
  selectedProduct = null;
  hideSuggestions();

  setTimeout(() => {
    content.style.transform = 'scale(1)';
    content.style.opacity   = '1';
  }, 10);

  setTimeout(() => {
    const input = document.getElementById('item-name');
    if (input) input.focus();
  }, 300);

  updateQuantityUnitLabel();
}

function hideAddItemModal() {
  const modal   = document.getElementById('add-item-modal');
  const content = document.getElementById('modal-content');
  const form    = document.getElementById('add-item-form');
  if (!modal || !content) return;

  content.style.transform = 'scale(0.95)';
  content.style.opacity   = '0';

  setTimeout(() => {
    modal.classList.add('hidden');
    if (form) form.reset();
    selectedProduct = null;
    hideSuggestions();
  }, 300);
}

function parseQuantityFromInput(raw) {
  if (!raw) return 1;
  const match = String(raw).match(/\d+/);
  if (!match) return 1;
  const n = parseInt(match[0], 10);
  if (Number.isNaN(n) || n <= 0) return 1;
  return n;
}

function initQuantityIntegerOnly() {
  const quantityInput = document.getElementById('item-quantity');
  if (!quantityInput) return;

  // Подсказываем браузеру, что тут только цифры
  quantityInput.setAttribute('inputmode', 'numeric');
  quantityInput.setAttribute('pattern', '[0-9]*');

  // Жёстко вычищаем всё, что не цифры
  quantityInput.addEventListener('input', () => {
    const digits = quantityInput.value.replace(/\D/g, '');
    if (quantityInput.value !== digits) {
      quantityInput.value = digits;
    }
  });
}


function initializeAddItemForm() {
  const form = document.getElementById('add-item-form');
  if (!form) return;

  // ограничиваем поле количества: только целые числа
  const qtyInput = document.getElementById('item-quantity');
  if (qtyInput) {
    qtyInput.addEventListener('input', () => {
      let value = qtyInput.value.replace(/[^\d]/g, '');
      // убираем ведущие нули
      value = value.replace(/^0+/, '');
      qtyInput.value = value;
    });
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const nameInput     = document.getElementById('item-name');
    const quantityInput = document.getElementById('item-quantity');

    const name        = nameInput ? nameInput.value.trim() : '';
    const quantityRaw = quantityInput ? quantityInput.value.trim() : '';

    if (!name) {
      showNotification('Введите название продукта');
      return;
    }

    let productToUse = selectedProduct;

    // если юзер не кликнул по подсказке — пробуем добрать точное совпадение через trie
    if (!productToUse) {
      const variants  = await searchProductsByPrefix(name, 10);
      const lowerName = name.toLowerCase();
      productToUse =
        variants.find((p) => (p.name || '').toLowerCase() === lowerName) || null;
    }

    if (!productToUse) {
      showNotification('Выберите продукт из списка подсказок — он должен существовать в БД');
      return;
    }

    selectedProduct = productToUse;

    const quantity = parseQuantityFromInput(quantityRaw) || 1;

    const newItem = await createInventoryItem(selectedProduct, quantity);
    if (!newItem) return;

    shoppingItems.push(newItem);
    renderShoppingList();
    updateStats();

    hideAddItemModal();
    showNotification(`${newItem.name} добавлено в список`);
  });
}

// ==== подсказки по продуктам ====

function initProductSearchUI() {
  const nameInput = document.getElementById('item-name');
  if (!nameInput) return;

  const hintEl = document.getElementById('item-name-hint');
  if (hintEl) {
    nameInput.addEventListener('focus', () => {
      hintEl.classList.remove('hidden');
    });
    nameInput.addEventListener('blur', () => {
      if (!nameInput.value.trim()) {
        hintEl.classList.add('hidden');
      }
    });
  }

  const parent = nameInput.parentElement || nameInput;
  suggestionsContainer = document.createElement('div');
  suggestionsContainer.id = 'product-suggestions';
  suggestionsContainer.className =
    'mt-1 border border-gray-200 rounded-xl bg-white shadow-lg max-h-60 ' +
    'overflow-y-auto text-sm hidden z-50';
  parent.appendChild(suggestionsContainer);

  nameInput.addEventListener('input', handleProductInput);

  suggestionsContainer.addEventListener('click', (e) => {
    const btn = e.target.closest('button[data-sugg-index]');
    if (!btn) return;
    const index   = Number(btn.dataset.suggIndex);
    const product = currentSuggestions[index];
    if (!product) return;

    selectedProduct = product;
    const input = document.getElementById('item-name');
    if (input) {
      input.value = product.name;
      input.focus();
    }

    updateQuantityUnitLabel();
    hideSuggestions();
  });

  document.addEventListener('click', (e) => {
    if (!suggestionsContainer) return;
    const input = document.getElementById('item-name');
    if (input && (input === e.target || input.contains(e.target))) return;
    if (suggestionsContainer.contains(e.target)) return;
    hideSuggestions();
  });
}

function handleProductInput(e) {
  const query = e.target.value.trim();
  selectedProduct = null;
  updateQuantityUnitLabel(); // очищаем / обновляем подпись единицы

  if (!query) {
    hideSuggestions();
    return;
  }

  if (productSearchDebounceId) {
    clearTimeout(productSearchDebounceId);
  }

  productSearchDebounceId = setTimeout(async () => {
    const matches = await searchProductsByPrefix(query, 10);

    currentSuggestions = matches;

    if (!matches.length) {
      hideSuggestions();
      return;
    }

    renderSuggestions(matches);
    updateQuantityUnitLabel();
  }, 200);
}

function renderSuggestions(list) {
  if (!suggestionsContainer) return;

  if (!list.length) {
    suggestionsContainer.classList.add('hidden');
    suggestionsContainer.innerHTML = '';
    return;
  }

  suggestionsContainer.innerHTML = list
    .map(
      (p, index) => `
      <button type="button"
              data-sugg-index="${index}"
              class="w-full text-left px-3 py-2 hover:bg-gray-100">
        ${p.name}
      </button>
    `,
    )
    .join('');

  suggestionsContainer.classList.remove('hidden');
}

function hideSuggestions() {
  if (!suggestionsContainer) return;
  suggestionsContainer.classList.add('hidden');
  suggestionsContainer.innerHTML = '';
  currentSuggestions = [];
}

// ==== прочее ====

async function generateFromMenu() {
  const user = getCurrentUserSafe();
  if (!user || !user.token) {
    showNotification('Войдите, чтобы сгенерировать список из меню');
    return;
  }

  // 1) Меню текущей недели из localStorage
  const weeklyMenu = loadCurrentWeekMenuFromStorage();
  const allIds = [
    ...weeklyMenu.monday,
    ...weeklyMenu.tuesday,
    ...weeklyMenu.wednesday,
    ...weeklyMenu.thursday,
    ...weeklyMenu.friday,
    ...weeklyMenu.saturday,
    ...weeklyMenu.sunday,
  ].filter((id) => id || id === 0);

  if (!allIds.length) {
    showNotification('На текущей неделе в меню нет рецептов');
    return;
  }

  // 2) Рецепты пользователя
  const recipes = await fetchUserRecipesForShopping();
  if (!recipes.length) {
    showNotification('Не удалось получить рецепты для меню');
    return;
  }

  // 3) Собираем ингредиенты из рецептов в меню (уже агрегированные по названию)
  const neededProducts = collectNeededProductsFromMenu(weeklyMenu, recipes);
  if (!neededProducts.length) {
    showNotification('В рецептах меню не найдено ингредиентов');
    return;
  }

  // 4) Карта уже существующих товаров по имени (чтобы суммировать, а не плодить дублей)
  const existingByName = new Map(
    shoppingItems
      .filter((i) => i.name)
      .map((i) => [i.name.toLowerCase().trim(), i]),
  );

  let updatedCount = 0;

  // 5) Для каждого нужного продукта – создаём/обновляем запись в /inventory
  for (const np of neededProducts) {
    if (!np.name) continue;

    const productName = np.name.trim();
    if (!productName) continue;

    const quantity = np.quantity || 1;

    // бэку достаточно product_name – собираем объект с name
    const newItem = await createInventoryItem({ name: productName }, quantity);
    if (!newItem) continue;

    const key = productName.toLowerCase();

    const existing = existingByName.get(key);
    if (existing) {
      // если такой продукт уже есть в списке — обновляем количество
      // (ориентируемся на то, что вернул сервер)
      existing.quantity = newItem.quantity ?? existing.quantity;
    } else {
      // если не было — просто добавляем
      shoppingItems.push(newItem);
      existingByName.set(key, newItem);
    }

    updatedCount++;
  }

  renderShoppingList();
  updateStats();

  if (updatedCount > 0) {
    showNotification(`Обновлено продуктов из меню: ${updatedCount}`);
  } else {
    showNotification('Не удалось добавить продукты из меню');
  }
}


async function clearAllPurchased() {
  const toDelete = shoppingItems.filter((i) => i.completed && i.id);

  for (const item of toDelete) {
    await deleteInventoryItem(item.id);
  }

  shoppingItems = shoppingItems.filter((i) => !i.completed);
  renderShoppingList();
  updateStats();
  showNotification('Купленные продукты удалены из списка');
}

function showNotification(message) {
  const notification = document.createElement('div');
  notification.className =
    'fixed top-20 right-4 bg-[#f6f7f8] text-[#292929] px-6 py-3 rounded-lg shadow-lg z-50 transform translate-x-full transition-transform duration-300';
  notification.textContent = message;

  document.body.appendChild(notification);

  setTimeout(() => {
    notification.style.transform = 'translateX(0)';
  }, 100);

  setTimeout(() => {
    notification.style.transform = 'translateX(100%)';
    setTimeout(() => {
      if (notification.parentNode) {
        notification.parentNode.removeChild(notification);
      }
    }, 300);
  }, 3000);
}

// закрытие модалки по клику по фону
document.addEventListener('click', (e) => {
  const modal = document.getElementById('add-item-modal');
  if (!modal || modal.classList.contains('hidden')) return;
  if (e.target === modal) hideAddItemModal();
});

// хоткеи
document.addEventListener('keydown', (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key === 'n') {
    e.preventDefault();
    showAddItemModal();
  }
  if (e.key === 'Escape') hideAddItemModal();
});

// анимация для плавающей кнопки
const floatingBtn = document.querySelector('.floating-add-btn');
if (floatingBtn && window.anime) {
  floatingBtn.addEventListener('mouseenter', function () {
    anime({ targets: this, scale: 1.1, duration: 200, easing: 'easeOutCubic' });
  });
  floatingBtn.addEventListener('mouseleave', function () {
    anime({ targets: this, scale: 1, duration: 200, easing: 'easeOutCubic' });
  });
}


// экспорт в window для inline-обработчиков
window.showAddItemModal = showAddItemModal;
window.hideAddItemModal = hideAddItemModal;
window.toggleItem      = toggleItem;
window.removeItem      = removeItem;
window.generateFromMenu = generateFromMenu;
window.clearAllPurchased = clearAllPurchased;
